<?php
	include_once("model/database.php");
	include_once("entite/new.php");

	$db = getDB();
	
	function getNews()
	{
		global $db;
		$req = $db->query('SELECT N.id, title, auteur AS auteurID, CONCAT(nom, " ", prenom) AS auteur,
			DATE_FORMAT(date_created, "%d/%m/%Y à %Hh%i") date_created, DATE_FORMAT(date_maj, "%d/%m/%Y à %Hh%i") date_maj, content
			FROM NEWS N LEFT JOIN UTILISATEUR U ON N.auteur = U.id ORDER BY N.id');

		$news = array();
		while ($res = $req->fetch())
			$news[] = new Actualite($res["id"], $res["title"], $res["auteurID"], $res["auteur"], $res["date_created"], $res["date_maj"], $res["content"]);
		return $news;
	}

	function getNew($id)
	{
		global $db;
		$req = $db->prepare('SELECT N.id, title, auteur AS auteurID, CONCAT(nom, " ", prenom) AS auteur,
			DATE_FORMAT(date_created, "%d/%m/%Y à %Hh%i") date_created, DATE_FORMAT(date_maj, "%d/%m/%Y à %Hh%i") date_maj, content
			FROM NEWS N LEFT JOIN UTILISATEUR U ON N.auteur = U.id WHERE N.id = :id');
		$req->exec(array(
			"id" => $id
		));

		$res = $req->fetch();
		if (is_array($res))
			return new Actualite($res["id"], $res["title"], $res["auteurID"], $res["auteur"], $res["date_created"], $res["date_maj"], $res["content"]);
		return null;
	}

	function addNew($new)
	{
		global $db;
		if ($new->getID() != null)
		{
			$req = $db->prepare("UPDATE NEWS SET title = :title, auteur = :auteur, date_maj = NOW(), content = :content WHERE 'id' = :id");
			$req->execute(array(
					"id" => $new-> getID(),
					"title" => $new->getTitle(),
					"auteur" => $new->getAuteurID(),
					"content" => $new->getRawContent(),
				));
		}
		else
		{
			$res = $db->prepare("INSERT INTO NEWS (title, auteur, date_created, date_maj, content) VALUES (:title, :auteur, NOW(), NOW(), :content)");
			$req->execute(array(
					"title" => $new->getTitle(),
					"auteur" => $new->getAuteurID(),
					"content" => $new->getRawContent(),
				));
		}
	}

	function deleteNew($id)
	{
		global $db;
		$req = $db->prepare("DELETE FROM NEWS WHERE id = :id");
		$req->execute(array(
					"id" => $id,
				));
	}