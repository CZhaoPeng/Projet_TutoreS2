<?php

	function getMessagesContact()
	{
		
	}

	function addMessageContact($mail, $content)
	{
		
	}

	function replyMessageContact($id, $title, $content)
	{

	}