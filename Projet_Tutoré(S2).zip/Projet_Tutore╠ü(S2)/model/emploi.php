<?php
	include_once("model/database.php");
	include_once("entite/emploi.php");

	$db = getDB();
	
	function getEmplois()
	{
		global $db;
		$req = $db->query('SELECT E.id, auteur AS auteurID, CONCAT(nom, " ", prenom) AS auteur,
			nom_emploi, DATE_FORMAT(date_created, "%d/%m/%Y à %Hh%i") date_created, content
			FROM EMPLOI E LEFT JOIN UTILISATEUR U ON E.auteur = U.id ORDER BY E.id');

		$emplois = array();
		while ($res = $req->fetch())
			$emplois[] = new Emploi($res["id"], $res["auteurID"], $res["auteur"], $res["nom_emploi"], $res["date_created"], $res["content"]);
		return $emplois;
	}

	function getEmploi($id)
	{
		global $db;
		$req = $db->prepare('SELECT E.id, auteur AS auteurID, CONCAT(nom, " ", prenom) AS auteur,
			nom_emploi, DATE_FORMAT(date_created, "%d/%m/%Y à %Hh%i") date_created, content
			FROM EMPLOI E LEFT JOIN UTILISATEUR U ON E.auteur = U.id ORDER BY E.id WHERE E.id = :id');
		$req->exec(array(
			"id" => $id
		));

		$res = $req->fetch();
		if (is_array($res))
			return new Actualite($res["id"], $res["auteurID"], $res["auteur"], $res["nom_emploi"], $res["date_created"], $res["content"]);
		return null;
	}

	function addEmploi($emploi)
	{
		global $db;
		if ($emploi->getID() != null)
		{
			$req = $db->prepare("UPDATE NEWS SET nom_emploi = :nom_emploi, auteur = :auteur, content = :content WHERE 'id' = :id");
			$req->execute(array(
					"id" => $emploi-> getID(),
					"auteur" => $emploi->getAuteurID(),
					"nom_emploi" => $emploi->getNomEmploi(),
					"content" => $emploi->getContent(),
				));
		}
		else
		{
			$res = $db->prepare("INSERT INTO NEWS (auteur, nom_emploi, content) VALUES (:auteur, :nom_emploi, :content)");
			$req->execute(array(
					"auteur" => $emploi->getAuteurID(),
					"nom_emploi" => $emploi->getNomEmploi(),
					"content" => $emploi->getContent(),
				));
		}
	}

	function deleteEmploi($id)
	{
		global $db;
		$req = $db->prepare("DELETE FROM EMPLOI WHERE id = :id");
		$req->execute(array(
					"id" => $id,
				));
	}