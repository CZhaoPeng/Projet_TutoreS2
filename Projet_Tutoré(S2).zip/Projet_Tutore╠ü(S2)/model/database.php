<?php
	$hote = "localhost";
	$dbName = "projet_re8g";
	$user = "projet_re8g";
	$password = "Y78pe8iXN8";

	function getDB()
	{
		global $hote, $dbName, $user, $password;
		try
		{
			return new PDO("mysql:host=".$hote.";dbname=".$dbName.";charset=utf8", $user, $password);
		}
		catch (Exception $e)
		{
			die("Erreur : ". $e->getMessage());
		}
	}
?>