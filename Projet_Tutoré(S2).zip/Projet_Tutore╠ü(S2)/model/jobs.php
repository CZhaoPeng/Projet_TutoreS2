<?php

	function getJobs()
	{
		
	}

	function addJobs($title, $content)
	{
		
	}

	function editJobs($id, $title, $content)
	{

	}

	function deleteJobs($id)
	{

	}