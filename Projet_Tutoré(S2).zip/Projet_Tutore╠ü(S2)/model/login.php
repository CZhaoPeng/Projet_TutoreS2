<?php
	include_once("model/database.php");

	$db = getDB();

	function db_connect_user($user)
	{
		global $db;
		if (isset($db))
		{
			$req = $db->prepare("SELECT * FROM UTILISATEUR WHERE identifiant = :pseudo AND mdp = :password");
			$req->execute(array(
				"pseudo" => $user->getUsername(),
				"password" => $user->getPassword(),
			));
			$res = $req->fetch();

			$user->setConnected(is_array($res));

			if ($user->isConnected())
			{
				$user->setID($res["id"]);
				$user->setMail($res["mail"]);
				$user->setNom($res["nom"]);
				$user->setPrenom($res["prenom"]);
				$user->setAdresse($res["adresse"]);
				$user->setCodePostal($res["code_postal"]);
				$user->setVille($res["ville"]);
			}
		}
	}