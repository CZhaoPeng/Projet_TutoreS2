<?php
	$title = "Stage";
	include("view/stage.html");