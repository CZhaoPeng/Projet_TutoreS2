<?php
	$title = "Erreur ".$error;
	switch ($error)
	{
		case "404": include("view/error/404.html"); break;
		default: include("view/error/error.html"); break;
	}