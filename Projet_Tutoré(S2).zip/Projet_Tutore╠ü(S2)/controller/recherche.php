<?php
	$title = "Recherche";
	if (isset($_GET["q"]))
		$action = array(
			"recherche" => $_GET["q"]
		);
	include("view/recherche.html");