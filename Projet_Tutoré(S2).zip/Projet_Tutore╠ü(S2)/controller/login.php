<?php	
	include_once("model/login.php");
	
	if(isset($_POST["user"]) && isset($_POST["password"]))
	{
		$user = new User($_POST["user"], $_POST["password"]);
		db_connect_user($user);
		if ($user->isConnected())
			$_SESSION["user"] = $user;
	}

	if (!isset($_SESSION["user"]) || !$_SESSION["user"]->isConnected())
	{
		$title = "Connexion";
		include("view/login.html");
	}
	else header("Location: /");