<?php
	$title = "Contact";
	include("view/contact.html");