<?php
	$title = "inscription";
	include("view/inscription.html");