<?php
	include("model/emploi.php");
	$title = "Emploi";
	$action["emplois"] = getEmplois();
	include("view/emploi.html");