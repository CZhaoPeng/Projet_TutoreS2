<?php
	include("model/news.php");
	if ($getVPage[1] == "add")
	{
		$title = "Ajouter une news";
		include("view/ajout_new.html");
	}
	else
	{
		$title = "Accueil";
		$action = array("news" => getNews());
		include("view/index.html");
	}