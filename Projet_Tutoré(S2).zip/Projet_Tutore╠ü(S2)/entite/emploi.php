<?php

class Emploi
{
	private $id;
	private $auteurID;
	private $auteur;
	private $nom_emploi;
	private $date_created;
	private $content;

	public function __construct()
	{
		$a = func_get_args(); 
		$i = func_num_args(); 
		if (method_exists($this,$f='__construct'.$i))
			call_user_func_array(array($this,$f),$a);
	}

	public function __construct3($auteurID, $nom_emploi, $content)
	{
		$this->auteurID = $auteurID;
		$this->nom_emploi = $nom_emploi;
		$this->content = $content;
	}

	public function __construct6($id, $auteurID, $auteur, $nom_emploi, $date_created, $content)
	{
		$this->id = $id;
		$this->auteurID = $auteurID;
		$this->auteur = $auteur;
		$this->nom_emploi = $nom_emploi;
		$this->date_created = $date_created;
		$this->content = $content;
	}

	public function getID()
	{
		return $this->id;
	}

	public function setID($id)
	{
		$this->id = $id;
	}

	public function getAuteurID()
	{
		return $this->auteurID;
	}

	public function setAuteurID($auteurID)
	{
		$this->auteurID = $auteurID;
	}

	public function getAuteur()
	{
		return $this->auteur;
	}

	public function setAuteur($auteur)
	{
		$this->auteur = $auteur;
	}

	public function getNomEmploi()
	{
		return $this->nom_emploi;
	}

	public function setNomEmploi($nom_emploi)
	{
		return $this->nom_emploi = $nom_emploi;
	}

	public function getDateCreated()
	{
		return $this->date_created;
	}

	public function setDateCreated($date_created)
	{
		$this->date_created = $date_created;
	}

	public function getContent()
	{
		return nl2br($this->content);
	}

	public function setContent($content)
	{
		$this->content = $content;
	}

}