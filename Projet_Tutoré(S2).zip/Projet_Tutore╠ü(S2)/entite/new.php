<?php

class Actualite
{
	private $id;
	private $title;
	private $auteurID;
	private $auteur;
	private $date_created;
	private $date_update;
	private $content;

	public function __construct()
	{
		$a = func_get_args(); 
		$i = func_num_args(); 
		if (method_exists($this,$f='__construct'.$i))
			call_user_func_array(array($this,$f),$a);
	}

	public function __construct3($title, $auteurID, $content)
	{
		$this->title = $title;
		$this->auteurID = $auteurID;
		$this->content = $content;
	}

	public function __construct7($id, $title, $auteurID, $auteur, $date_created, $date_update, $content)
	{
		$this->id = $id;
		$this->title = $title;
		$this->auteurID = $auteurID;
		$this->auteur = $auteur;
		$this->date_created = $date_created;
		$this->date_update = $date_update;
		$this->content = $content;
	}

	public function getID()
	{
		return $this->id;
	}

	public function setID($id)
	{
		$this->id = $id;
	}

	public function getTitle()
	{
		return $this->title;
	}

	public function setTitle($title)
	{
		$this->title = $title;
	}

	public function getAuteurID()
	{
		return $this->auteurID;
	}

	public function setAuteurID($auteurID)
	{
		$this->auteurID = $auteurID;
	}

	public function getRawAuteur()
	{
		return $this->auteur;
	}

	public function getAuteur()
	{
		return isset($this->auteur) ? $this->auteur:"Inconnu";
	}

	public function setAuteur($auteur)
	{
		$this->auteur = $auteur;
	}

	public function getDateCreate()
	{
		return $this->date_created;
	}

	public function setDateCreate($date_created)
	{
		$this->date_created = $date_created;
	}

	public function getDateUpdate()
	{
		return $this->date_update;
	}

	public function setDateUpdate($date_update)
	{
		$this->date_update = $date_update;
	}

	public function getRawContent()
	{
		return $this->content;
	}

	public function getContent()
	{
		$texte = $this->content;
		$texte = preg_replace('#\[b\](.+)\[/b\]#isU', '<span style="font-weight:bold">$1</span>', $texte); //gras
		$texte = preg_replace('#\[i\](.+)\[/i\]#isU', '<span style="font-style:italic">$1</span>', $texte); //italique
		$texte = preg_replace('#\[u\](.+)\[/u\]#isU', '<span style="text-decoration:underline">$1</span>', $texte); //souligné
		$texte = preg_replace('#\[center\](.+)\[/center\]#isU', '<div style="text-align:center">$1</div>', $texte); //centré
		$texte = preg_replace('#\[img\](.+)\[/img\]#isU', '<img src="$1" alt="Image" class="image"/>', $texte);  //image
		$texte = preg_replace('#\[strike\](.+)\[/strike\]#isU', '<span style="text-decoration:line-through">$1</span>', $texte);  //barré
		$texte = preg_replace('#\[url\](.+)\[/url\]#isU', '<a href="$1" rel="nofollow" >$1</a>', $texte);  //url
		$texte = preg_replace('#\[url=(.+)\](.+)\[/url\]#isU', '<a href="$1" rel="nofollow" >$2</a>', $texte);  //url+text
		$texte = preg_replace('#\[color=\#(.+)\](.+)\[/color\]#isU', '<span style="color:#$1;">$2</span>', $texte);  //couleur
		$texte = preg_replace('#\[size=(.+)\](.+)\[/size\]#isU', '<span style="font-size:$1%;">$2</span>', $texte);  //taille
		return nl2br($texte);
	}

	public function setContent($content)
	{
		$this->content = $content;
	}
}