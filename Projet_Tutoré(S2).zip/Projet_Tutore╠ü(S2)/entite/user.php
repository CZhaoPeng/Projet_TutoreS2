<?php

class User
{
	private $id;
	private $connected = false;
	private $username;
	private $password;
	private $mail;
	private $nom;
	private $prenom;
	private $adresse;
	private $codePostal;
	private $ville;


	public function __construct()
	{
		$a = func_get_args(); 
		$i = func_num_args(); 
		if (method_exists($this,$f='__construct'.$i))
			call_user_func_array(array($this,$f),$a);
	}

	public function __construct2($username, $password)
	{
		$this->username = $username;
		$this->password = hash("sha512", $password);
	}

	public function __construct9($id, $username, $password, $mail, $nom, $prenom, $adresse, $codePostal, $ville)
	{
		$this->id = $id;
		$this->username = $username;
		$this->password = $password;
		$this->mail = $mail;
		$this->nom = $nom;
		$this->prenom = $prenom;
		$this->adresse = $adresse;
		$this->codePostal = $codePostal;
		$this->ville = $ville;
	}

	public function getID()
	{
		return $this->id;
	}

	public function setID($id)
	{
		$this->id = $id;
	}

	public function isConnected()
	{
		return $this->connected;
	}

	public function setConnected($connected)
	{
		$this->connected = $connected;
	}

	public function getUsername()
	{
		return $this->username;
	}

	public function setUsername($username)
	{
		$this->username = $username;
	}

	public function getPassword()
	{
		return $this->password;
	}

	public function setPassword($password)
	{
		$this->password = hash("sha512", $password);
	}

	public function getMail()
	{
		return $this->mail;
	}

	public function setMail($mail)
	{
		$this->mail = $mail;
	}

	public function getNom()
	{
		return $this->nom;
	}

	public function setNom($nom)
	{
		$this->nom = $nom;
	}

	public function getPrenom()
	{
		return $this->prenom;
	}

	public function setPrenom($prenom)
	{
		$this->prenom = $prenom;
	}

	public function getAdresse()
	{
		return $this->adresse;
	}

	public function setAdresse($adresse)
	{
		$this->adresse = $adresse;
	}

	public function getCodePostal()
	{
		return $this->codePostal;
	}

	public function setCodePostal($codePostal)
	{
		$this->codePostal = $codePostal;
	}

	public function getVille()
	{
		return $this->ville;
	}

	public function setVille($ville)
	{
		$this->ville = $ville;
	}
}