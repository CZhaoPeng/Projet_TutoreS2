<?php
	include("config/paths.php");
	include_once("entite/user.php");
	session_start();

	$getVPage = isset($_GET["action"]) ? explode("/", $_GET["action"]):array();
	ob_start();
	if (isset($getVPage[0]))
	{
		if ($getVPage[0] == "erreur")
			$error = isset($getVPage[1]) ? $getVPage[1]:"404";
		else
		{
			$controllerName = getControllerNameWithPath($getVPage[0]);
			if (isset($controllerName))
				include("controller/".$controllerName.".php");
			else $error = "404";
		}
	}
	else include("controller/".getControllerNameWithPPName("page_index").".php");
	$content = ob_get_clean();
	
	if (isset($error))
	{
		ob_start();
		include("controller/error.php");
		$content = ob_get_clean();
	}

	if (isset($_GET["theme"]) && is_file("public/style/".$_GET["theme"].".css"))
		$theme = $_SESSION["theme"] = $_GET["theme"];
	elseif (isset($_SESSION["theme"]) && is_file("public/style/".$_SESSION["theme"].".css"))
		$theme = $_SESSION["theme"];
	else $theme = "new_style";
	include("view/template.html");
?>