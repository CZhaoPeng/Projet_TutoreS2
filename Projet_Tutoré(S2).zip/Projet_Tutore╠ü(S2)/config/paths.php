<?php
	$pathsPage = array(
		"page_index" => array(
			"path" => "accueil", 
			"controller" => "accueil"
		),
		"page_inscription" => array(
			"path" => "inscription", 
			"controller" => "inscription"
		),
		"page_login" => array(
			"path" => "login", 
			"controller" => "login"
		),
		"page_logout" => array(
			"path" => "logout", 
			"controller" => "logout"
		),
		"page_compte" => array(
			"path" => "compte", 
			"controller" => "contact"
		),
		"page_stage" => array(
			"path" => "stage", 
			"controller" => "stage"
		),
		"page_emploi" => array(
			"path" => "emploi", 
			"controller" => "emploi"
		),
		"page_recherche" => array(
			"path" => "recherche", 
			"controller" => "recherche"
		),
		"page_contact" => array(
			"path" => "contact", 
			"controller" => "contact"
		),
	);

	function getPathWithPPName($name)
	{
		global $pathsPage;
		if (isset($pathsPage[$name]))
			return $pathsPage[$name]["path"];
		return null;
	}

	function getControllerNameWithPPName($name)
	{
		global $pathsPage;
		if (isset($pathsPage[$name]))
			return $pathsPage[$name]["controller"];
		return null;
	}

	function getControllerNameWithPath($path)
	{
		global $pathsPage;
		foreach ($pathsPage as $key => $value)
			if ($path == $value["path"])
				return $value["controller"];
		return null;
	}